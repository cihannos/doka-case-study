import React, { useState, useEffect } from "react";
import axios from "axios";
import Loader from "./components/Loader";

export default function MovieDetail() {


    // GETTING FILM IMDB ID FROM URL
    let url_string = new URL(window.location.href);
    const movie_id = url_string.searchParams.get("ref");


    // OMDB API URL
    const API = "https://www.omdbapi.com/?apikey=4f7d7d93";


    // FILM DATA STATE
    const [filmData, setFilmData] = useState(null);

    //PAGE LOAD
    useEffect(() => {

        // CHECK IF MOVIE EXIST IN CACHE
        if (localStorage.getItem("movie-" + movie_id)) {

            // IF FILMDATA EXIST IN CACHE SETTING STATE FROM CACHE
            setFilmData(JSON.parse(localStorage.getItem("movie-" + movie_id)));

        } else {

            // IF NOT EXIST IN CACHE GET FILM DATA FROM OMDBAPI AND SAVE CACHE
            axios.get(API + '&i=' + movie_id).then(response => {
                setFilmData(response.data);
                localStorage.setItem("movie-" + movie_id, JSON.stringify(response.data));
            });

        }
    }, []);


    // IF FILMDATA IS EXIST
    if (filmData) {
        return (
            <div className="container text-dark py-5 mb-5">
                <h1 className="mt-5 text-primary">{filmData.Title}</h1>
                <div className="row mt-5 px-0">
                    <div className="col-lg-4 mx-0 px-0 p-0">
                        {
                            filmData.Poster === "N/A" || !filmData.Poster
                                ?
                                <img src="https://www.invenura.com/wp-content/themes/consultix/images/no-image-found-360x250.png" />
                                :
                                <img src={filmData.Poster} />
                        }
                    </div>
                    <div className="col-lg-8 mx-0 px-0">

                        <h1 className="lead">Movie Details</h1>
                        <ul style={{ padding: 0 }} className="movieDetailsList">
                            {filmData.Year === "N/A" || !filmData.Year ? null : <li>Year: <span>{filmData.Year}</span></li>}
                            {filmData.Rated === "N/A" || !filmData.Rated ? null : <li>Rated: <span>{filmData.Rated}</span></li>}

                            {filmData.Released === "N/A" || !filmData.Released ? null : <li>Released: <span>{filmData.Released}</span></li>}
                            {filmData.Runtime === "N/A" || !filmData.Runtime ? null : <li>Runtime: <span>{filmData.Runtime}</span></li>}
                            {filmData.Genre === "N/A" || !filmData.Genre ? null : <li>Genre: <span>{filmData.Genre}</span></li>}
                            {filmData.Director === "N/A" || !filmData.Director ? null : <li>Director: <span>{filmData.Director}</span></li>}
                            {filmData.Writer === "N/A" || !filmData.Writer ? null : <li>Writer: <span>{filmData.Writer}</span></li>}
                            {filmData.Plot === "N/A" || !filmData.Plot ? null : <li>Plot: <span>{filmData.Plot}</span></li>}
                            {filmData.Metascore === "N/A" || !filmData.Metascore ? null : <li>Metascore: <span>{filmData.Metascore}</span></li>}
                            {filmData.imdbRating === "N/A" || !filmData.imdbRating ? null : <li>IMDB Rating: <span>{filmData.imdbRating}</span></li>}
                            {filmData.imdbVotes === "N/A" || !filmData.imdbVotes ? null : <li>IMDB Votes: <span>{filmData.imdbVotes}</span></li>}
                            {filmData.imdbID === "N/A" || !filmData.imdbID ? null : <li>IMDB ID: <span>{filmData.imdbID}</span></li>}
                            {filmData.Type === "N/A" || !filmData.Type ? null : <li>Type: <span>{filmData.Type}</span></li>}
                            {filmData.DVD === "N/A" || !filmData.DVD ? null : <li>DVD: <span>{filmData.DVD}</span></li>}
                            {filmData.BoxOffice === "N/A" || !filmData.BoxOffice ? null : <li>BoxOffice: <span>{filmData.BoxOffice}</span></li>}
                            {filmData.Production === "N/A" || !filmData.Production ? null : <li>Production: <span>{filmData.Production}</span></li>}
                            {filmData.Website === "N/A" || !filmData.Website ? null : <li>Website: <span>{filmData.Website}</span></li>}
                            {
                                filmData.Ratings === "N/A" || !filmData.Ratings ?
                                    null
                                    :
                                    <li>
                                        Ratings:
                                        <ul style={{ padding: 0, listStyle: "none" }}>
                                            {
                                                filmData.Ratings.map((ratingData, index) => {
                                                    return <li key={index} className="border border-dark m-1 p-1">{ratingData.Source} - {ratingData.Value} </li>
                                                })
                                            }
                                        </ul>
                                    </li>
                            }
                        </ul>

                    </div>
                </div>
            </div>
        );
    } else {
        return (
            <Loader />
        )
    }
}