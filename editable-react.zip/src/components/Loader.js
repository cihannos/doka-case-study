import React from "react";

export default function Loader() {
    return (
        <div className="movieloader"><i className="fas fa-spinner fa-spin"></i></div>
    );
}