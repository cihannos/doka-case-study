import React, { useState } from "react";
import { Link } from "react-router-dom";
import noposter from '../noposter.png';


export default function FilmCard(props) {


    return (
        <div className="filmcard">


            <div className="row-line p-0 m-0" style={{ border: "2px solid #ddd" }}>
                <div className="thumbcontainer px-0">
                    {
                        props.thumb != "N/A" ?
                            <Link to={"moviedetail?ref=" + props.imdbid}><img alt="Movie Poster" src={props.thumb} /></Link>
                            :
                            <Link to={"moviedetail?ref=" + props.imdbid}><img alt="Movie Poster" src={noposter} /></Link>
                    }
                </div>
                <div className="datacontainer p-2" style={{ fontSize: "14px" }}>
                    <div className="filmTitle">
                        <a><Link to={"moviedetail?ref=" + props.imdbid}>{props.filmName}</Link></a>
                    </div>
                    <div className="p-1" style={{ borderTop: "1px solid #555", marginTop: "3px" }}>
                        <i className="fas fa-chevron-right fa-xs"></i> {props.year}
                    </div>
                    <div className="p-1" style={{ borderTop: "1px solid #555", borderBottom: "1px solid #555", marginTop: "3px" }}>
                        <i className="fas fa-chevron-right fa-xs"></i> IMDB ID: {props.imdbid}
                    </div>
                    <Link to={"moviedetail?ref=" + props.imdbid} className="watchfilm btn btn-success text-light rounded-pill w-100 mt-2">Details</Link>
                </div>
            </div>
        </div>
    );
}