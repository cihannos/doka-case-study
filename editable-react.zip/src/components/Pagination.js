import React, { useState, useEffect } from "react";


export default function Pagination(props) {

    // STATES
    const [limit, setLimit] = useState(10);
    const [lastPage, setLastPage] = useState(0);
    const [begin, setBegin] = useState(0);
    const [currentPage, setcurrentpage] = useState(props.currentPage);
    const [result, setResult] = useState(props.result);
    const [search, setSearch] = useState(props.search);
    const [searchSystem, setSearchSystem] = useState("");

    // PAGE LOAD
    useEffect(() => {
        if (props.results < 10) {
            setLastPage(2)
        } else {
            setLastPage(Math.ceil(props.results / limit))
        }

    }, []);


    
    // DEDECT WHEN SEARCH INPUT CHANGED
    useEffect(() => {
        setResult(props.results)

        // IF TOTAL REQUEST COUNT IS UNDER 10 SET TOTAL PAGE
        if (props.results < 10) {
            setLastPage(2)
        } else {
            setLastPage(Math.ceil(props.results / limit))
        }

        // SET DEFAULT PAGE = 1
        setcurrentpage(1)

        // IF SEARCH TEXT IS EXIST CREATE SEARCH PARAMETER FOR GET QUERY
        if (props.search !== null) {
            setSearchSystem("&search=" + props.search);
        } else {
            setSearchSystem("");
        }
    }, [props.search]);




    return (
        <div className="pagination d-flex justify-content-center my-5">
            {
                result && lastPage != 0 ?
                    <nav aria-label="Page navigation">
                        <ul className="pagination">
                            {
                                // ALL PAGINATION ITEMS HERE !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                                Number(props.currentPage) !== 0 && Number(props.currentPage) !== null && Number(props.currentPage) !== 1
                                    ?
                                    <li className="page-item"><a className="page-link bg-dark text-light" href={"./?page=1" + searchSystem}>{"<<"}</a></li>
                                    :
                                    null
                            }
                            {
                                Number(props.currentPage) !== 0 && Number(props.currentPage) !== null && Number(props.currentPage) !== 1
                                    ?
                                    <li className="page-item disabled"><a className="page-link bg-dark text-light">...</a></li>
                                    :
                                    null
                            }
                            {
                                Number(props.currentPage) !== 0 && Number(props.currentPage) !== null && Number(props.currentPage) !== 1
                                    ?
                                    <li className="page-item"><a className="page-link bg-dark text-light" href={"./?page=" + Number(Number(props.currentPage) - 1) + searchSystem}>{"<"}</a></li>
                                    :
                                    null
                            }
                            {
                                Number(props.currentPage) !== 0 && Number(props.currentPage) !== null && Number(props.currentPage) !== 1 && Number(props.currentPage) !== 2
                                    ?
                                    <li className="page-item"><a className="page-link bg-dark text-light" href={"./?page=" + Number(Number(props.currentPage) - 2) + searchSystem}>{Number(props.currentPage - 2)}</a></li>
                                    :
                                    null
                            }
                            {
                                props.currentPage != 0 && props.currentPage != null && props.currentPage != 1
                                    ?
                                    <li className="page-item"><a className="page-link bg-dark text-light" href={"./?page=" + Number(Number(props.currentPage) - 1) + searchSystem}>{Number(props.currentPage) - 1}</a></li>
                                    :
                                    null
                            }
                            {
                                props.currentPage === null
                                    ?
                                    <li className="page-item disabled"><a className="page-link bg-secondary text-light" href="#">1</a></li>
                                    :
                                    <li className="page-item disabled"><a className="page-link bg-secondary text-light" href="#">{Number(props.currentPage)}</a></li>
                            }
                            {
                                props.currentPage === null
                                    ?
                                    <li className="page-item"><a className="page-link bg-dark text-light" href={"./?page=" + Number(Number(props.currentPage) + 2) + searchSystem}>{Number(props.currentPage) + 2}</a></li>
                                    :
                                    null
                            }
                            {
                                props.currentPage === null
                                    ?
                                    <li className="page-item"><a className="page-link bg-dark text-light" href={"./?page=" + Number(Number(props.currentPage) + 3) + searchSystem}>{Number(props.currentPage) + 3}</a></li>
                                    :
                                    null
                            }
                            {
                                props.currentPage != Number(lastPage - 1) && props.currentPage != Number(lastPage - 1) && props.currentPage != null
                                    ?
                                    <li className="page-item"><a className="page-link bg-dark text-light" href={"./?page=" + Number(Number(props.currentPage) + 1) + searchSystem}>{Number(props.currentPage) + 1}</a></li>
                                    :
                                    null
                            }
                            {
                                props.currentPage != Number(lastPage - 1) && props.currentPage != Number(lastPage - 2) && props.currentPage != null
                                    ?
                                    <li className="page-item"><a className="page-link bg-dark text-light" href={"./?page=" + Number(Number(props.currentPage) + 2) + searchSystem}>{Number(props.currentPage) + 2}</a></li>
                                    :
                                    null
                            }
                            {
                                props.currentPage != null && props.currentPage != Number(lastPage - 1)
                                    ?
                                    <li className="page-item"><a className="page-link bg-dark text-light" href={"./?page=" + Number(Number(props.currentPage) + 1) + searchSystem}>{">"}</a></li>
                                    :
                                    null
                            }
                            {
                                props.currentPage === 0 || props.currentPage === null
                                    ?
                                    <li className="page-item"><a className="page-link bg-dark text-light" href={"./?page=" + Number(Number(props.currentPage) + 2) + searchSystem}>{">"}</a></li>
                                    :
                                    null
                            }
                            {
                                props.currentPage != Number(lastPage - 1)
                                    ?
                                    <li className="page-item disabled"><a className="page-link bg-dark text-light">...</a></li>
                                    :
                                    null
                            }
                            {
                                props.currentPage != Number(lastPage - 1)
                                    ?
                                    <li className="page-item"><a className="page-link bg-dark text-light" href={"./?page=" + Number(lastPage - 1) + searchSystem}>{">>"}</a></li>
                                    :
                                    null
                            }




                        </ul>
                    </nav>
                    :
                    null
            }
        </div>
    );

}