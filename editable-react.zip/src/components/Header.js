import React from "react";
import { Link } from "react-router-dom";


export default function Header() {
    return (
        <nav className="navbar navbar-light text-light p-3" style={{backgroundColor:"#000"}}>
            <Link to="./" className="navbar-brand text-light">DokaMovie</Link>
        </nav>
    );
}