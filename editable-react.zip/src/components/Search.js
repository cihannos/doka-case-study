import React, { useEffect, useState } from "react";

export default function Search(props) {


    return (
        <div className="search">
            <div className="searchTitle">Search Movie What You Want</div>
            <div className="searchGroup" dokadataname="searchContainer">
                <i className="fas fa-search"></i>
                <i className="fas fa-spinner fa-spin" style={{ display: "none" }}></i>
                <input placeholder="Search" onChange={(e) => { props.searchFilms(e.target.value); } } />
            </div>
        </div>
    );
}