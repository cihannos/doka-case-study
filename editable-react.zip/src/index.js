import React from 'react';
import ReactDOM from 'react-dom';
import './custom.css';

// REACT-ROUTER
import { BrowserRouter, Route, Link } from 'react-router-dom';

// MAIN PAGE
import MainPage from './mainPage';

// MOVIE DETAILS PAGE
import MovieDetail from './movieDetail';


// HEADER
import Header from './components/Header';

// APP CALL | CREATE PAGE
function DokaMovie() {
    return (
        <div className="DokaMovies">
            <Header />
            <Route exact path='/'>
                <MainPage />
            </Route>
            <Route exact path="/moviedetail" >
                <MovieDetail />
            </Route>
        </div>
    );
}


// RENDER
ReactDOM.render(
    <BrowserRouter basename={process.env.PUBLIC_URL}>
        <DokaMovie />
    </BrowserRouter>,
    document.getElementById("root")
);