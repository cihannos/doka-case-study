import React, { useState, useEffect, useCallback } from "react";
import { useHistory } from "react-router-dom";
import axios from "axios";
import Loader from "./components/Loader";

// SEARCH
import Search from './components/Search';

// FİLM CARDS
import FilmCard from './components/FilmCard';

// PAGINATION
import Pagination from './components/Pagination';

export default function MainPage() {

    // STATES
    const API = "https://www.omdbapi.com/?apikey=4f7d7d93";
    const [films, setFilms] = useState(null);
    const [page, setPage] = useState(null);
    const [resultcount, setResultCount] = useState(0);
    const [searchingContent, setSearchingContent] = useState(null);

    //PAGE LOAD
    useEffect(() => {
        // SET EMPTY ARRAY TO MOVIES FOR CALL GET FILMS EFFECT
        let gettingFilms = [];
        setFilms(gettingFilms);


        // GETTING PAGE FROM URL
        let url_string = new URL(window.location.href);
        const page = setPage(url_string.searchParams.get("page"));


        // IF SEARCH EXIST SET STATE
        if (url_string.searchParams.get("search") !== null) {
            setSearchingContent(url_string.searchParams.get("search"));
        }


    }, []);


    // IF FILMS CHANGED
    useEffect(() => {
        getFilms();
    }, [films]);


    // GET FILMS
    const getFilms = () => {
        if (films != null) {
            if (films.length === 0) {
                let gettingFilmDatas = [];

                // SETTING FOR GET 2 PAGE DATA
                if (page) {
                    var pageData = "&page=" + page;
                    var pageData2 = "&page=" + Number(Number(page) + 1)
                } else {
                    var pageData = "&page=1";
                    var pageData2 = "&page=2";
                }


                // IF ANY SEARCH PARAMETER EXIST SET SEARCH, IF NOT SEARCH FOR BASIC THE POWER
                var searchingContentABS;
                if (searchingContent) {
                    searchingContentABS = searchingContent;
                } else {
                    searchingContentABS = "the power";
                }


                // API REQUEST
                axios.get(API + '&s=' + searchingContentABS + pageData).then(res => {
                    if (res.data.Search) {
                        setResultCount(res.data.totalResults);
                        res.data.Search.map((data) => {
                            gettingFilmDatas.push(data);
                        });
                        axios.get(API + '&s=' + searchingContentABS + pageData2).then(res1 => {
                            res1.data.Search.map((data) => {
                                gettingFilmDatas.push(data);
                            });
                            setFilms(gettingFilmDatas);
                        });
                    }
                });
            }

        }
    }

    // IF SEARCH INPUT CHANGED (WORKS WITH 1000 MS)
    let searchingTimeout;
    const searchFilms = (content) => {
        if (content) {

            // RESET PAGES AND TOTAL RESULTS
            setResultCount(0);
            setPage(1);
            clearTimeout(searchingTimeout);
            searchingTimeout = setTimeout(function () {

                // CHECK IF SEARCH EXIST
                if (content) {

                    // SET SEARCH TEXT
                    setSearchingContent(content);
                    document.getElementsByClassName("fa-search")[0].style.display = "none";
                    document.getElementsByClassName("fa-spinner")[0].style.display = "inline-block";
                    let gettingFilmDatas = [];

                    // API REQUEST
                    axios.get(API + '&s=' + content).then(res => {
                        if (res.data.Search) {
                            setResultCount(res.data.totalResults);
                            res.data.Search.map((data) => {
                                gettingFilmDatas.push(data);
                            });
                            axios.get(API + '&s=' + content + "&page=2").then(res1 => {
                                if (res1.data.Search) {
                                    res1.data.Search.map((data) => {
                                        gettingFilmDatas.push(data);
                                    });
                                    setFilms(gettingFilmDatas);

                                    document.getElementsByClassName("fa-search")[0].style.display = "inline-block";
                                    document.getElementsByClassName("fa-spinner")[0].style.display = "none";
                                } else {
                                    document.getElementsByClassName("fa-search")[0].style.display = "inline-block";
                                    document.getElementsByClassName("fa-spinner")[0].style.display = "none";
                                    setFilms(gettingFilmDatas);
                                }
                            });
                        } {
                            setTimeout(function () {
                                document.getElementsByClassName("fa-search")[0].style.display = "inline-block";
                                document.getElementsByClassName("fa-spinner")[0].style.display = "none";
                            }, 2000);
                        }
                    });

                } else {
                    document.getElementsByClassName("fa-search")[0].style.display = "inline-block";
                    document.getElementsByClassName("fa-spinner")[0].style.display = "none";
                }
            }, 1000);
        } else {
            document.getElementsByClassName("fa-search")[0].style.display = "inline-block";
            document.getElementsByClassName("fa-spinner")[0].style.display = "none";
        }
    }

    // IF MOVIES IS EXIST
    if (films != null) {
        return (<
            div className="mainPage" >
            <
                Search searchFilms={searchFilms}
            /> <
            div className="filmcards-container row" > {

                    films ?
                        // BASIC FOREACH LOOP FOR CREATING FilmCard COMPONENTS WITH PROPERTIES
                        films.map((filmData, index) => (<
                            FilmCard key={index}
                            filmName={filmData.Title}
                            thumb={filmData.Poster}
                            year={filmData.Year}
                            imdbid={filmData.imdbID}
                        />
                        )) :
                        null
                } <
            /div> {
                    // PAGINATION HERE
                } {
                    resultcount != 0 ? < Pagination search={searchingContent}
                        results={resultcount}
                        currentPage={page}
                    /> : null} <
                /div>
                );
        }
                else {
            return ( <
                div className="mainPage" >
                    <
                        Search />
                    <
                        Loader />
                    <
                /div>
                    );
        }
    }